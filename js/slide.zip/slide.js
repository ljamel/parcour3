// Création d'un prototype Slide avec 2 objets
function slide(image, myIndex) {
    this.slideIndex = image;
    this.myIndex = myIndex;
}

// Initialisation des valeurs des 2 objets
// Initialise la variable monSlide.slideIndex a 1 pour commencer par la première image puis monSlide.myIndex à 0.
monSlide = new slide(1, 0);

console.log(monSlide.slideIndex + 2);
console.log(monSlide.myIndex);

showDivs(monSlide.slideIndex);

// Incremente la variable monSlide.slideIndex pour passer a l'image suivante
function plusDivs(n) {
    showDivs(monSlide.slideIndex += n);
}

// function des cursers
function showDivs(n) {
    var x = document.getElementsByClassName("mySlides");
    if (n > x.length) {
        monSlide.slideIndex = 1
    }
    if (n < 1) {
        monSlide.slideIndex = x.length
    }
    for (i = 0; i < x.length; i++) {
        x[i].style.display = "none";
    }
    x[monSlide.slideIndex - 1].style.display = "block";
}

// Affiche des informations sur un événement clavier
// Déplacement des images avec la touche directionnelle
function infosClavier(m) {


    // Déplacement ver la droite
    if (m.keyCode === 39 || monSlide.myIndex === -1) {

        var i;
        var x = document.getElementsByClassName("mySlides");
        for (i = 0; i < x.length; i++) {
            x[i].style.display = "none";
        }
        monSlide.myIndex++;
        if (monSlide.myIndex > x.length) {
            monSlide.myIndex = 1;
        }
        x[monSlide.myIndex - 1].style.display = "block";

    }
    // Déplacement ver la gauche
    if (m.keyCode === 37) {

        var x = document.getElementsByClassName("mySlides");
        for (i = 0; i < x.length; i++) {
            x[i].style.display = "none";
        }
        monSlide.myIndex--;
        if (monSlide.myIndex < 1) {
            monSlide.myIndex = 3;
        }
        x[monSlide.myIndex - 1].style.display = "block";

    }


}
// Gestion de l'appui et du relâchement d'une touche du clavier
document.addEventListener("keydown", infosClavier);
